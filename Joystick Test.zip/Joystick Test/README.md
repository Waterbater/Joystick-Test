# Roy the RPG

Hey, Scratchers! This is a sample repository to put Scratch projects into Android/Amazon Apps.
Feel free to fork my repo and upload your own game to the App Stores.

[nitrodragon.github.io](http://nitrodragon.github.io/royroyroyroy)
## How to compile
This is the compiled repository with the source code of nathan/phosphorus and an `index.html` file linked to the Scratch project that I'm using as a demonstration. All you need to do to link your project is **change** `var ProjectID` **to the number at the end of your project's URL.**

## How to port
After that, just use Adobe PhoneGap to port your newly-created web app to an `.apk`/`.ipa` file. If you have any questions, just check [the official forum topic on Scratch](https://scratch.mit.edu/discuss/topic/91282/?page=2). If you can't find what you're looking for, just post your question.
